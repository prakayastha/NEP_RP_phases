import numpy as np
from ase.build import bulk, make_supercell, surface
from ase.calculators.emt import EMT
from ase.io import read, write
import ase
import ase.io
from calorine.tools import relax_structure
from hiphive.structure_generation import generate_mc_rattled_structures

prototype_structures = {}
prototype_structures['Ba2ZrS4']   = ase.io.read("Ba2ZrS4_geometry.in", format='aims')
prototype_structures['Ba3Zr2S7']  = ase.io.read("Ba3Zr2S7_geometry.in", format='aims') 
prototype_structures['Ba4Zr3S10'] = ase.io.read("Ba4Zr3S10_geometry.in", format='aims')

def generate_strained_structure(prim, strain_lim):
    strains = np.random.uniform(*strain_lim, (3, 3))
    atoms = prim.copy()
    cell_new = prim.cell[:] * (1 + strains)
    atoms.set_cell(cell_new, scale_atoms=True)
    return atoms


def generate_deformed_structure(prim, strain_lim):
    R = np.random.uniform(*strain_lim, (3, 3))
    M = np.eye(3) + R
    atoms = prim.copy()
    cell_new = M @ atoms.cell[:]
    atoms.set_cell(cell_new, scale_atoms=True)
    return atoms


# parameters
strain_lim = [-0.05, -0.02, -0.01, 0.01, 0.02, 0.05]
n_structures = 30

training_structures = []
for name, prim in prototype_structures.items():
    for it in range(n_structures):
        prim_strained = generate_strained_structure(prim, strain_lim)
        prim_deformed = generate_deformed_structure(prim, strain_lim)

        training_structures.append(prim_strained)
        training_structures.append(prim_deformed)

print('Number of training structures:', len(training_structures))
