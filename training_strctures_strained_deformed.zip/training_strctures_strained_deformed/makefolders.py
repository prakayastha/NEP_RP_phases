import os
from ase.io import read
import ase

for i in range(1,181):
        os.mkdir('calc_%s'%i)
        os.chdir('calc_%s'%i)
        os.system('mv ../geometry.in-%s geometry.in'%i)
        os.system('cp ../control.in .')
        os.chdir('../')
